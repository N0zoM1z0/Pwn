import rm64

encoders = rm64.encoders
for encoder in encoders:
  encoder["case"] = "mixedcase"

