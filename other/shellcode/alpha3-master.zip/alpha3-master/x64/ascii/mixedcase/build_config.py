build_config = {
  "folders": [
    u'rm64'
  ]
}
