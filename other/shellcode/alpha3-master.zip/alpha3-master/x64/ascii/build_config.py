build_config = {
  "folders": [
    u'mixedcase'
  ]
}
