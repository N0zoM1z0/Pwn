import ascii;

encoders = ascii.encoders;
for encoder in encoders:
  encoder["architecture"] = "x64"
