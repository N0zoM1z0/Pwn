#!/bin/sh
python ./ALPHA3.py x64 ascii mixedcase $1 --input="shellcode"
