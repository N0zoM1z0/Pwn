python ALPHA3.py x86 ascii mixedcase $1 --input=shellcode_x86
