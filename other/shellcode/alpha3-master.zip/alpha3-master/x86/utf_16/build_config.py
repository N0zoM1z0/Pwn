build_config = {
  "folders": [
    u'mixedcase',
    u'uppercase'
  ]
}
