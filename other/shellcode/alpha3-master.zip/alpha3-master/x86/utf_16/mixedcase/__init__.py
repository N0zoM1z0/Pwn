encoders = []
for encoder in encoders:
  encoder["case"] = "mixedcase"
