build_config = {
  "projects": {
    u'x86\\ascii_latin_1\\mixedcase\\getpc\\call': {
      "files": {
        u'ECX+2.bin': {
          "sources": [u'ECX+2.asm']
        }
      }
    }
  }
}
