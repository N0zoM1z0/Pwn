build_config = {
  "folders": [
    u'getpc'
  ]
}
