build_config = {
  "projects": {
    u'x86\\ascii\\lowercase\\rm32': {
      "files": {
        u'EBX.bin': {
          "sources": [u'EBX.asm']
        },
        u'ECX.bin': {
          "sources": [u'ECX.asm']
        },
        u'EDX.bin': {
          "sources": [u'EDX.asm']
        }
      }
    }
  }
}
