build_config = {
  "folders": [
    u'lowercase',
    u'mixedcase',
    u'uppercase'
  ]
}
