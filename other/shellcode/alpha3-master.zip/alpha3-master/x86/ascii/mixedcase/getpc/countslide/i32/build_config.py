build_config = {
  "projects": {
    u'x86\\ascii\\mixedcase\\getpc\\countslide\\i32': {
      "files": {
        u'[i32] - ECX.bin': {
          "sources": [u'[i32] - ECX.asm']
        }
      }
    }
  }
}
