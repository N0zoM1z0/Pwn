build_config = {
  "folders": [
    u'countslide',
    u'seh'
  ]
}
