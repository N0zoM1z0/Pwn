build_config = {
  "projects": {
    u'x86\\ascii\\mixedcase\\getpc\\countslide\\rm32': {
      "files": {
        u'[EAX+i32] - EDX.bin': {
          "sources": [u'[EAX+i32] - EDX.asm']
        },
        u'[EBX+i32] - EDX.bin': {
          "sources": [u'[EBX+i32] - EDX.asm']
        },
        u'[ECX+i32] - EDX.bin': {
          "sources": [u'[ECX+i32] - EDX.asm']
        },
        u'[EDX+i32] - EDX.bin': {
          "sources": [u'[EDX+i32] - EDX.asm']
        },
        u'[ESI+i32] - EDX.bin': {
          "sources": [u'[ESI+i32] - EDX.asm']
        },
        u'[EDI+i32] - EDX.bin': {
          "sources": [u'[EDI+i32] - EDX.asm']
        },
      }
    }
  }
}
