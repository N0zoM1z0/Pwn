build_config = {
  "projects": {
    u'x86\\ascii\\mixedcase\\getpc\\seh\\xpsp3': {
      "files": {
        u'ESI+4.bin': {
          "sources": [u'ESI+4.asm']
        },
        u'[ESI].bin': {
          "sources": [u'[ESI].asm']
        }
      }
    }
  }
}
