build_config = {
  "projects": {
    u'x86\\ascii\\mixedcase\\i32': {
      "files": {
        u'dwx_IMUL_30_XOR_dwy.bin': {
          "sources": [u'dwx_IMUL_30_XOR_dwy.asm']
        },
        u'dwx_IMUL_by.bin': {
          "sources": [u'dwx_IMUL_by.asm']
        }
      }
    }
  }
}
